%clear all;
load('sthlm1118.mat');

%according to folkhalsomyndigheten Sthlm had 9.7 seroprevalence in mid october,
%which we take as the value on 1st of october since it takes 2-3 weeks to
%develop antibodies. This means that the value in september was 10. In early march
%the seroprevalence was around 22.6 which thus should correspond to the
%value in mid February, which is day 168 in the time series. The increase in 
%seroprevalence was thus 12.6 percent. To compute the
%under reporting factor among the 2.400.000 inhabitants, we do

correction_factor=0.126*2400000/sum(sthlm(1:168))

immunity_increase_total=0.126*sum(sthlm)/sum(sthlm(1:168))

%which yields 2.4

figure(2)
plot(correction_factor*sthlm,'LineWidth',2);hold on;
title('New infections, Stockholm county');
axis([1 length(sthlm) 0 4400]);
xticks([1 31 62 92 123 154 182 213 243 274 304 335 366 396 427 457])
xticklabels({'Sept.','Oct.','Nov.','Dec.','Jan.','Feb.','Mar.','Apr.','May','June', 'July','Aug.','Sept','Oct','Nov'})
hold off;
 
