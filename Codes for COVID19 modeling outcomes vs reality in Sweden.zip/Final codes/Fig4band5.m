load('Google_mobility_Stockholm_20200215_to_20220727.mat');
x=Google_mobility_Stockholm_20200215_to_20220727;
f=zeros(size(x)-[6 0]);
favg=zeros(1,6);
for j=1:6,
   f(:,j)=conv(x(:,j),[1 1 1 1 1 1 1]/7,'valid');
   favg(j)=sum(f(200:229,j))/30;%this corresponds to the month of september
   f_adjusted_for_september=100*(f-favg)./(favg+100);
end
f_adjusted_for_september(:,3)=[];%Parks data is not interesting


f_short=f_adjusted_for_september(200:485,:)%This corresponds to the dates 20200901 to 20210613

figure(1);
plot(f_short,'LineWidth',2);
axis([1 275 -50 15])
title({'Mobility Data, Stockholm County'},'FontSize',14)
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sep. 2020','Oct.','Nov.','Dec.','Jan. 2021','Feb.','Mar.','Apr.','May','Jun.', 'July'})
text(110-1,-63,'\downarrow X-mas break','Color','k');
text(52-1,-63,'\downarrow Autumn break','Color','k');
text(213-1,-63,'\downarrow Easter break','Color','k');
%text(182-1,-58,'\downarrow Sport break','Color','k');
lgd=legend({'Retail and Recreation','Grocery and Pharmacy','Transit stations','Workplaces','Residential'},'Position',[0.6 0.2 0.22 0.14]);
lgd.FontSize=11;

figure(2);
plot(f_adjusted_for_september,'LineWidth',2);
axis([1 888 -50 40])
title({'Mobility Data, Stockholm County'},'FontSize',18)
xticks([15 200 322 473 687 838])
xticklabels({'Mar. 2020','Sept. 2020','Jan. 2021','June 2021','Jan. 2022','June 2022'})
text(110-1,-63,'\downarrow X-mas break','Color','k');
text(52-1,-63,'\downarrow Autumn break','Color','k');
text(213-1,-63,'\downarrow Easter break','Color','k');
%text(182-1,-58,'\downarrow Sport break','Color','k');
lgd=legend({'Retail and Recreation','Grocery and Pharmacy','Transit stations','Workplaces','Residential'},'Position',[0.2 0.75 0.12 0.14]);
lgd.FontSize=15;
