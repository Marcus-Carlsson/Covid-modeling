clear all;
% parameter values
load('stockholm_data_weekly_average_200901_to_210603.mat');
load('cases_wuhan_strain')
load('vaccinated_by_day.mat');
cases_total=2.4*stockholm_data_weekly_average_sept2020_to_may_2021;%2.4 is the underreportingfactor, see Fig 1
cases_wuhan=2.4*cases_wuhan_strain;
v=vaccinated_by_day;

% parameter values (explained in Fig3and4a.m)
t_infective = 2.1;gamma = 1/t_infective;
t_incubation = 4.6;sigma = 1/t_incubation;
xi=1/4;
number_of_days = length(cases_total);
N=2400000;
half_life=16/12*365;
psi=0.102;
w=[0.058 0.084 0.060 0.259 0.390 0.149];%'0-5','6-12','13-19','20-39','40-69','>70'%original used by wallinga w_age=[0.0725 0.0866 0.1124 0.3323 0.2267 0.1695];
A=CreateA(w,xi);
N_G=length(w);
%these parameters are new, corresponding to preimmunity against the two
%strains
theta_orig=0.65;
theta_alpha=0.56;
%corresponding beta values must be substantially higher
beta_orig=0.475;
beta_alpha=0.475;%it turns out we do not need to increase this one at all
T_vacgroup5=123+120;%120 means 4 months...

%we set initial conditions the same way as in Fig3and4a
[x1,alpha1,a1,b1]=CreateInitialDistribution(A,(1-theta_orig)*w,sigma,gamma,beta_orig);
R_init=N*psi*x1';
s_init_temp=(1-theta_orig)*w-R_init/N;
[x1,alpha1,a1,b1]=CreateInitialDistribution(A,s_init_temp,sigma,gamma,beta_orig);
I_init=cases_total(1)*1.5/sum(diag(s_init_temp)*beta_orig*A*x1)*x1';
E_init=a1/b1*I_init;
S_init=N*w-E_init-I_init-R_init;


%we now create the variales S,E,I,R and NU, which collects new cases
%In addition, we need new variables that keep track of alpha 
R=zeros(N_G,number_of_days);R(:,1) = R_init;
E=zeros(N_G,number_of_days);E(:,1) = E_init;
I=zeros(N_G,number_of_days);I(:,1) = I_init;
S=zeros(N_G,number_of_days);S(:,1) = S_init;
NU=zeros(N_G,number_of_days);

T_alpha=67;%this is the date we assume that Stockholm had the first imports of alpha.
%This number is chosen manually to have a good overall fit
E_alpha=zeros(N_G,number_of_days);
I_alpha=zeros(N_G,number_of_days);
I_alpha(:,T_alpha) = 10*w';%we assume 10 import cases on the day T_alpha
NU_alpha=zeros(N_G,number_of_days);

%this is an update of the key code found on lines 76-83 in Fig3and4a.m, as
%described in Appendix A6-A9, without removing for vaccinations

for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N-theta_orig*w')*beta_orig*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
if t>=T_alpha,
    NU_alpha(:,t)=diag(S(:,t)/N-theta_alpha*w')*beta_alpha*A*I_alpha(:,t);
    E_alpha(:,t+1)=E_alpha(:,t)+(NU_alpha(:,t)-sigma*E_alpha(:,t));
    I_alpha(:,t+1)=I_alpha(:,t)+(sigma*E_alpha(:,t)-gamma*I_alpha(:,t));
end
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)-NU_alpha(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+gamma*I_alpha(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

%now we remove the vaccinations
NUV=zeros(N_G,number_of_days);
NUV_alpha=zeros(N_G,number_of_days);

for t=1:number_of_days-1,
NUV(:,t)=diag(S(:,t)/N-theta_orig*w')*beta_orig*A*I(:,t);
E(:,t+1)=E(:,t)+(NUV(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
if t>=T_alpha,
    NUV_alpha(:,t)=diag(S(:,t)/N-theta_alpha*w')*beta_alpha*A*I_alpha(:,t);
    E_alpha(:,t+1)=E_alpha(:,t)+(NUV_alpha(:,t)-sigma*E_alpha(:,t));
    I_alpha(:,t+1)=I_alpha(:,t)+(sigma*E_alpha(:,t)-gamma*I_alpha(:,t));
end
S(:,t+1)=S(:,t)-NUV(:,t)-NUV_alpha(:,t)+(log(2)/half_life)*R(:,t);
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+gamma*I_alpha(:,t);
end
% 
% 
% 
% C19midfeb=sum(r(:,168))/N
% 
% R0_true_sept=beta_orig*max(eig(diag(w)*Abold))/gamma
% R0_sept=beta_orig*max(eig(diag(w)*Abold))/gamma*(1-theta_orig-psi)
% R0VoC_true_feb=beta_alpha*max(eig(diag(w)*Abold))/gamma
% R0VoC_true_feb=beta_alpha*max(eig(diag(w)*Abold))/gamma*(1-theta_alpha-C19midfeb)


%plotting

figure(2)
plot(cases_total,'b','LineWidth',2);hold on;
plot(cases_wuhan,'LineWidth',2);
plot(cases_total-cases_wuhan,'LineWidth',2);
plot(cases_total(1:200),'b--','LineWidth',2);
plot(sum(NU,1),'LineWidth',2);
plot(sum(NU_alpha,1),'LineWidth',2);
plot(sum(NU,1)+sum(NU_alpha,1),'k--','LineWidth',2);

NUV_tot=sum(NUV,1)+sum(NUV_alpha,1);
plot([215:276],NUV_tot(215:276),'m--','LineWidth',2);


axis([1 number_of_days-1 0 4400]);
title('New infections, Stockholm county');
legend({'','','','','Model Wuhan strain','Model alpha strain','Model Total','Model Total w/o vaccinations'},'Location','NW')
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sept.','Oct.','Nov.','Dec.','Jan.','Feb.','Mar.','Apr.','May','June', 'July'})
hold off;
