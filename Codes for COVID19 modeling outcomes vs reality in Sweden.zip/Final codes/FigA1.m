load('vaccinated_by_day.mat');
plot(vaccinated_by_day(123:276),'LineWidth',2);%first of january 2021 is day 123
title('Vaccination roll out 2021','FontSize',14);
xticks([1 32 60 91 121 152])
xticklabels({'Jan.','Feb.','Mar.','Apr.','May.','Jun.'});
ylabel('Fraction of total population with 2 shots','FontSize',15)
