function [x1,alpha1,a1,b1]=CreateInitialDistribution(A,s_t0,sigma,gamma,beta)

%This script finds initial distributions given an estimate of s(t_0),
%following the description in Section A4-A5 of the Appendix A

[E,D]=eig(beta*diag(s_t0)*A);
x1=E(:,1);
x1=sign(x1(1))*x1;
x1=x1/sum(x1);
alpha1=D(1,1);
M=[-sigma alpha1;
    sigma -gamma];
[E,D]=eig(M);
a1=E(1,1);
b1=E(2,1);