%clear all;
load('stockholm_data_weekly_average_200901_to_210603');
cases=stockholm_data_weekly_average_sept2020_to_may_2021;

%according to Folkhalsomyndigheten Seroprevalence data, Stockholm had 
%9.8 seroprevalence in mid october 2020,
%which we take as the value on 1st of october since it takes 2-3 weeks to
%develop antibodies. Using interpolation between the 11.2 value registered in june 2020, 
%this means that the value in early september was 10.2. In
%early march 2021
%the measured seroprevalence was around 22.8 which thus (using the 3 week delay logic above) 
%should correspond to the
%value in mid February, which is day 168 in the time series. The increase in 
%seroprevalence was thus 12.6 percent. To compute the
%under reporting factor among the 2.400.000 inhabitants, we do

percentage_registered_cases=sum(cases(1:168))/2400000;
correction_factor=0.126/percentage_registered_cases

%which yields 2.4. 

immunity_increase_total_until_june_2021=2.4*sum(cases)/2400000



figure(2)
plot(cases,'LineWidth',2);hold on;
plot(correction_factor*cases,'b','LineWidth',2);
title('New infections, Stockholm county','FontSize',14);
axis([1 length(cases) 0 4400]);
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sep. 2020','Oct.','Nov.','Dec.','Jan. 2021','Feb.','Mar.','Apr.','May','Jun.', 'July'})
text(54,120,'1','Color','b');
text(62,120,'2','Color','b');
text(84,120,'3','Color','b');
text(114,120,'4','Color','b');
text(130,120,'5','Color','b');
text(98,163,'\downarrow','Color','r');
text(213+9,163,'\downarrow','Color','r');
text(99,308,'|','Color','r');
text(213+10,308,'|','Color','r');
text(99,163,'|','Color','r');
text(213+10,163,'|','Color','r');
text(98-45,500,'High Schools Close','FontSize',11,'Color','r');
text(213-50,500,' High Schools Reopen','FontSize',11,'Color','r');
text(110-1,163,'\downarrow','Color','k');
text(52-1,163,'\downarrow','Color','k');
text(213-1,163,'\downarrow','Color','k');

text(110-3,300,' X-mas break','FontSize',11,'Color','k');
text(52-5,300,'Autumn break','FontSize',11,'Color','k');
text(213-44,300,'Easter break','FontSize',11,'Color','k');
lgd=legend({'Data from the Swedish PHA','Data rescaled by a factor of 2.4\newline to account for underreporting'})
lgd.FontSize = 11;
hold off;
 
