clear all;
% parameter values
load('stockholm_data_weekly_average_200901_to_210603.mat');
load('vaccinated_by_day.mat');
st=2.4*stockholm_data_weekly_average_200901_to_210603;%2.4 is the underreportingfactor, see Fig 1
sto=2.4*vaccinated_by_day;

% parameter values

psi=0.10;%sero-prevalence September
%With a halflife of 1.5 years, which fits perfectly with the measurement of
%11.3 in June and 9.7 in October, we estimate the seroprevalence to 10% on
%the first of september

 theta=0.62;
 thetaVoC=0.52;
%original pre-immunity as estimated from the "influenza"-paper
 beta=0.349;
 betaVoC=0.38;
 T_VoC=70;
T_newyear=123;%this is the day the vaccinations begin, the 21 day delay is built into the sequence vac

% according to https://www.regionstockholm.se/verksamhet/halsa-och-vard/nyheter-vaccin-covid-19/2021/04/region-stockholm-oppnar-upp-vaccinering-for-65-plus/
%the vaccination of 65+ started 15th of april in stockholm, which means
%that these people will start to develop immunity early may
T_vacgroup5=123+120;%120 means 4 months...
 T_window=365*0.75;%for modeling purposes
%T_window=number_of_days-1;%for modeling purposes


t_infective = 2.1;gamma = 1/t_infective;
t_incubation = 4.6;sigma = 1/t_incubation;
delta=1;%factor for group isolation
xi=1/4;%factor for isolation of elderly
number_of_days = 1500;
N=2400000;%population_size
half_life=16/12*365;

%swedish population 2020
w=[0.058 0.084 0.060 0.259 0.390 0.149];%'0-5','6-12','13-19','20-39','40-69','>70'%original used by wallinga w_age=[0.0725 0.0866 0.1124 0.3323 0.2267 0.1695];
%we have updated the quota (using https://population.un.org/) and made the last group 70+ instead of 60+

%contact matrix
Abold=CreateA(w,xi);

%number of subgroups
N_G=length(w);
%now comes formula (12) relating R0 and beta


%we now get the initial conditions right by solving the equation starting
%with a low amount of exposed and a fixed value of pre-immune

r_init=N*w'*(theta+psi);
e_init= 10*w';
i_init=zeros(N_G,1);
s_init=N*w';
s_init=s_init-e_init-i_init-r_init;
nu_init=zeros(N_G,1);
t=1;
%the value 1.3 is chosen ad hoc to get a nice overall fit
while sum(nu_init)<1.3*st(1),
    t=t+1;
    nu_init=diag(s_init)/N*beta*Abold*i_init;
    e_temp=e_init+nu_init-sigma*e_init;
    i_temp=i_init+sigma*e_init-gamma*i_init;
    s_init=s_init-nu_init;
    r_init=r_init+gamma*i_init;
    e_init=e_temp;
    i_init=i_temp;
end


%initial values


r=zeros(N_G,number_of_days);r(:,1)=N*w'*psi;
e=zeros(N_G,number_of_days);e(:,1) = e_init;
i=zeros(N_G,number_of_days);i(:,1) = i_init;
s=N*diag(w)*ones(N_G,number_of_days);
s=s-e-i-r;
nu=zeros(N_G,number_of_days);

eVoC=zeros(N_G,number_of_days);
iVoC=zeros(N_G,number_of_days);
iVoC(:,T_VoC) = 10*w';
nuVoC=zeros(N_G,number_of_days);


for t=1:T_newyear-1,
nu(:,t)=diag(s(:,t)/N-theta*w')*beta*Abold*i(:,t);
e(:,t+1)=e(:,t)+(nu(:,t)-sigma*e(:,t));
i(:,t+1)=i(:,t)+(sigma*e(:,t)-gamma*i(:,t));
if t>=T_VoC,
    nuVoC(:,t)=diag(s(:,t)/N-thetaVoC*w')*betaVoC*Abold*iVoC(:,t);
    eVoC(:,t+1)=eVoC(:,t)+(nuVoC(:,t)-sigma*eVoC(:,t));
    iVoC(:,t+1)=iVoC(:,t)+(sigma*eVoC(:,t)-gamma*iVoC(:,t));
end
s(:,t+1)=s(:,t)-nu(:,t)-nuVoC(:,t)+(log(2)/half_life)*r(:,t);
r(:,t+1)=r(:,t)*1-(log(2)/half_life)*r(:,t)+gamma*iVoC(:,t)+gamma*i(:,t);
end

frac6=[ones(1,T_vacgroup5) linspace(1,0,7) zeros(1,276-T_vacgroup5-7)];
frac5=ones(1,276)-frac6;


for t=T_newyear:276-1,
nu(:,t)=diag(s(:,t)/N-theta*w')*beta*Abold*i(:,t);
e(:,t+1)=e(:,t)+(nu(:,t)-sigma*e(:,t));
i(:,t+1)=i(:,t)+(sigma*e(:,t)-gamma*i(:,t));
nuVoC(:,t)=diag(s(:,t)/N-thetaVoC*w')*betaVoC*Abold*iVoC(:,t);
eVoC(:,t+1)=eVoC(:,t)+(nuVoC(:,t)-sigma*eVoC(:,t));
iVoC(:,t+1)=iVoC(:,t)+(sigma*eVoC(:,t)-gamma*iVoC(:,t));
vaccinated=(v(t+1-(T_newyear-1))-v(t-(T_newyear-1)))*0.9;
s(:,t+1)=s(:,t)-nu(:,t)-nuVoC(:,t)+(log(2)/half_life)*r(:,t)-vaccinated*frac6(t)*s(6,T_newyear)/w(6)*[0 0 0 0 0 1]'-vaccinated*frac5(t)*s(5,T_vacgroup5)/w(5)*[0 0 0 0 1 0]';
r(:,t+1)=r(:,t)*1-(log(2)/half_life)*r(:,t)+gamma*iVoC(:,t)+gamma*i(:,t)+vaccinated*frac6(t)*s(6,T_newyear)/w(6)*[0 0 0 0 0 1]'+vaccinated*frac5(t)*s(5,T_vacgroup5)/w(5)*[0 0 0 0 1 0]';
end



rNV=zeros(N_G,number_of_days);rNV(:,1)=N*w'*psi;
eNV=zeros(N_G,number_of_days);eNV(:,1) = e_init;
iNV=zeros(N_G,number_of_days);iNV(:,1) = i_init;
sNV=N*diag(w)*ones(N_G,number_of_days);
sNV=sNV-eNV-iNV-rNV;
nuNV=zeros(N_G,number_of_days);

eVoCNV=zeros(N_G,number_of_days);
iVoCNV=zeros(N_G,number_of_days);
iVoCNV(:,T_VoC) = 10*w';
nuVoCNV=zeros(N_G,number_of_days);


for t=1:276-1,
nuNV(:,t)=diag(sNV(:,t)/N-theta*w')*beta*Abold*iNV(:,t);
eNV(:,t+1)=eNV(:,t)+(nuNV(:,t)-sigma*eNV(:,t));
iNV(:,t+1)=iNV(:,t)+(sigma*eNV(:,t)-gamma*iNV(:,t));
if t>=T_VoC,
    nuVoCNV(:,t)=diag(sNV(:,t)/N-thetaVoC*w')*betaVoC*Abold*iVoCNV(:,t);
    eVoCNV(:,t+1)=eVoCNV(:,t)+(nuVoCNV(:,t)-sigma*eVoCNV(:,t));
    iVoCNV(:,t+1)=iVoCNV(:,t)+(sigma*eVoCNV(:,t)-gamma*iVoCNV(:,t));
end
sNV(:,t+1)=sNV(:,t)-nuNV(:,t)-nuVoCNV(:,t)+(log(2)/half_life)*rNV(:,t);
rNV(:,t+1)=rNV(:,t)*1-(log(2)/half_life)*rNV(:,t)+gamma*iVoCNV(:,t)+gamma*iNV(:,t);
end




C19midfeb=sum(r(:,168))/N

R0_true_sept=beta*max(eig(diag(w)*Abold))/gamma
R0_sept=beta*max(eig(diag(w)*Abold))/gamma*(1-theta-psi)
R0VoC_true_feb=betaVoC*max(eig(diag(w)*Abold))/gamma
R0VoC_true_feb=betaVoC*max(eig(diag(w)*Abold))/gamma*(1-thetaVoC-C19midfeb)


%plotting
figure(1)
plot(sum(r,1)/N,'LineWidth',2);
axis([1 T_window 0 0.5]);


figure(2)
plot(st,'b','LineWidth',2);hold on;
plot(sto,'LineWidth',2);
plot(st-sto,'LineWidth',2);
plot(st(1:200),'b--','LineWidth',2);
plot(sum(nu,1),'LineWidth',2);
plot(sum(nuVoC,1),'LineWidth',2);
plot(sum(nu,1)+sum(nuVoC,1),'--','LineWidth',2);

nuNV=sum(nuNV,1)+sum(nuVoCNV,1);
plot([170:276],nuNV(170:276),'m--','LineWidth',2);


axis([1 T_window 0 4400]);
xlabel('Time in months');
title('New infections, Stockholm county');
legend({'','','','','Model Wuhan strain','Model alpha strain','Model Total','Model w/o vacc.'},'Location','NW')
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sept.','Oct.','Nov.','Dec.','Jan.','Feb.','Mar.','Apr.','May','June', 'July'})
hold off;
