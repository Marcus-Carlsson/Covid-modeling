%clear all;
% parameter values
load('stockholm_data_weekly_average_200901_to_210603');
load('cases_wuhan_strain');
cases_total_rescaled=2.4*stockholm_data_weekly_average_sept2020_to_may_2021;%2.4 is the underreportingfactor, obtained in Fig1a.m
cases_wuhan_rescaled=2.4*cases_wuhan_strain;


%plotting

figure(1)
plot(cases_total_rescaled,'b','LineWidth',2);hold on;
plot(cases_wuhan_rescaled,'LineWidth',2);
plot(cases_total_rescaled-cases_wuhan_rescaled,'LineWidth',2);
plot(cases_total_rescaled(1:200),'b--','LineWidth',2);
axis([1 length(cases_total_rescaled) 0 4400]);
%xlabel('Time in days');
title('New infections, separated by strain','FontSize',14);
lgd=legend({'Total','Wuhan-strain','Alpha-strain'})
lgd.FontSize=11;
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sep. 2020','Oct.','Nov.','Dec.','Jan. 2021','Feb.','Mar.','Apr.','May','Jun.', 'July'})
%text(98,158,'\downarrow','Color','k');
%text(213,158,'\downarrow','Color','k');
%text(98-60,298,'High Schools Close','Color','k');
%text(213-60,298,' High Schools Reopen','Color','k');


hold off;
 
