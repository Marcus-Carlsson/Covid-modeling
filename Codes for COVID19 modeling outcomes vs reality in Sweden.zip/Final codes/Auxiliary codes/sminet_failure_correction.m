%Sminet, the swedish COVID reporting system, had some tecnical troubles end
%of may 2021, leading to 0 covid cases registered on 3 days. These cases were
%instead registered on two subsequent dates. This script corrects this by
%adding cases to the 3 days and removing from the later two days. The
%number 150 is chosen to match number of cases on other days nearby dates

load('stockholm_data_raw.mat')

x=stockholm_data_raw;

x(479)=150;
x(480)=150;
x(481)=150;
x(482)=x(482)-150;
x(484)=x(484)-300;

stockholm_data_corrected=x;

save('stockholm_data_corrected.mat','stockholm_data_corrected')