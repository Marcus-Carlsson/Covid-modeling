%This code creates an approximation of the amount of cases of the original
%strain of SARS-CoV-2 in stockholm county, based on measured cases (7 day
%rolling average) and weekly fraction of B.1.1.7 among cases for the weeks
%5 to 13. To make the data smooth, we interpolate piecewise linearly so that the increase
%starts at week 3 at 0 and ends at 93% at the end of week 13. We
%interpolate linearly down to 0 at the end of the time series, which is 3rd
%of June 2021 when the Wuhan strain was completely gone and delta was about
%to emerge
clear all;
load('stockholm_data_weekly_average_200901_to_210603');
cases_total=stockholm_data_weekly_average_sept2020_to_may_2021;
cases_wuhan_strain=cases_total;

offset=7;%since it takes 5 days to get symptoms and another two to get tested, we argue
%that what is measured say week 7, actually represents week 6, therefore
%the offset

%week 3 of 2021 coincides with day 140 in the data set
%week 3, no data, we model starting at 0 and ending 9
for j=0:6,
cases_wuhan_strain(140-offset+j)=cases_total(140-offset+j)*(100-(0+j*9/6))/100;
end


%week 4, no data, we model starting at 10 and ending 20
for j=0:6,
cases_wuhan_strain(147-offset+j)=cases_total(147-offset+j)*(100-(10+j*10/6))/100;
end

%the data for week 5 and 6 is 27%, so we put 23% in week 5 and 31% in week 6,
%since the value for week 7 is 41 this creates a reasonable graph

%week 5, 23% B117, 2% other VoC, which we model starting at 21 and ending
%29

for j=0:6,
cases_wuhan_strain(154-offset+j)=cases_total(154-offset+j)*(100-(21+j*8/6))/100;
end

%week 6, 31% B117, 4% other VoC, which we model starting at 30 and ending
%40
for j=0:6,
cases_wuhan_strain(161-offset+j)=cases_total(161-offset+j)*(100-(30+j*10/6))/100;
end

%week 7, 41% B117, 6% other VoC, which we model starting at 41 and ending
%53
for j=0:6,
cases_wuhan_strain(168-offset+j)=cases_total(168-offset+j)*(100-(41+j*12/6))/100;
end

%week 8, 53% B117, 6% other VoC, which we model starting at 54 and ending
%64
for j=0:6,
cases_wuhan_strain(175-offset+j)=cases_total(175-offset+j)*(100-(54+j*10/6))/100;
end

%week 9, 66% B117, 5% other VoC, which we model starting at 65 and ending
%77
for j=0:6,
cases_wuhan_strain(182-offset+j)=cases_total(182-offset+j)*(100-(66+j*12/6))/100;
end

%week 10, 79% B117, 3% other VoC, which we model starting at 80 and ending
%84
for j=0:6,
cases_wuhan_strain(189-offset+j)=cases_total(189-offset+j)*(100-(80+j*4/6))/100;
end

%week 11, 84% B117, 3% other VoC, which we model starting at 84 and ending
%90
for j=0:6,
cases_wuhan_strain(196-offset+j)=cases_total(196-offset+j)*(100-(84+j*6/6))/100;
end

%week 12, 88% B117, 4% other VoC, which we model starting at 91 and ending
%93
for j=0:6,
cases_wuhan_strain(203-offset+j)=cases_total(203-offset+j)*(100-(91+j*2/6))/100;
end

%week 13, 92% B117, 2% other VoC, which we model starting at 93 and ending
%95
for j=0:6,
cases_wuhan_strain(210-offset+j)=cases_total(210-offset+j)*(100-(93+j*2/6))/100;
end


%for the remainder we interpolate linearly down to 0
for j=0:66,
cases_wuhan_strain(217-offset+j)=cases_wuhan_strain(209)*(66-j)/66;
end


plot(cases_wuhan_strain)

save('cases_wuhan_strain.mat','cases_wuhan_strain')


