function y=interpolate_sthlm3wave(x)
%sminet, the swedish COVID reporting system, had some tecnical troubles end
%of may, leading to 0 covid cases registered on 3 days. This script fills
%these places and removes same number from suspiciously high registrations
%on two subsequent dates
y=x;
y(269)=150;
y(270)=150;
y(271)=150;
y(272)=y(272)-150;
y(274)=y(274)-300;