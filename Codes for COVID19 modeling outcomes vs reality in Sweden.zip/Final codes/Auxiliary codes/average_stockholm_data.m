%this script computes the weekly average from the raw data (after sminet failure correction)
load('stockholm_data_corrected.mat')
stockholm_data_weekly_average=conv(stockholm_data_corrected,1/7*[1 1 1 1 1 1 1],'valid');
save('stockholm_data_weekly_average_200204_to_220727.mat','stockholm_data_weekly_average');
%the time period we focus on in this paper is 1st september 2020, which is
%day 211 in the full time series, until 3rd of june 2021, which is a total
%of 276 days
stockholm_data_weekly_average_sept2020_to_may_2021=stockholm_data_weekly_average(211:486);
save('stockholm_data_weekly_average_200901_to_210603.mat','stockholm_data_weekly_average_sept2020_to_may_2021');
