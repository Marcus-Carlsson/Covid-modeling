clear all;
% load data
load('stockholm_data_weekly_average_200901_to_210603');
load('cases_wuhan_strain');
cases_total=2.4*stockholm_data_weekly_average_sept2020_to_may_2021;%2.4 is the underreportingfactor, obtained in Fig1a.m
cases_wuhan=2.4*cases_wuhan_strain;
load('vaccinated_by_day.mat');
v=vaccinated_by_day;



% parameter values
t_infective = 2.1;gamma = 1/t_infective;
t_incubation = 4.6;sigma = 1/t_incubation;
xi=1/4;%factor for isolation of elderly
number_of_days = length(cases_total);
N=2400000;%population_size
half_life=16/12*365;%16 months halflife as estimated in [24]
psi=0.102;%sero-prevalence September first
beta=0.119;%This number is chosen manually so that the increase during september matches data
%while keeping f around 0
%swedish population 2020, divided into 6 age groups
w=[0.058 0.084 0.060 0.259 0.390 0.149];%'0-5','6-12','13-19','20-39','40-69','>70'%original used by wallinga w_age=[0.0725 0.0866 0.1124 0.3323 0.2267 0.1695];
%we have updated the quota (using https://population.un.org/) and made the last group 70+ instead of 60+
%contact matrix
A=CreateA(w,xi);
%number of subgroups
N_G=length(w);




%initial values, we use capital letters for actual number of cases and 
%lower case letters for corresponding fractions, obtained by dividing by N
%The setting of the initial values follows the description in Sections A4
%and A5 of the manuscript
[x1,alpha1,a1,b1]=CreateInitialDistribution(A,w,sigma,gamma,beta);
%We first compute the distribution of recovered at the start of the
%pandemic
R_init=N*psi*x1';
s_init_temp=w-R_init/N;
%on the first day, 20200901, We know that s_init is roughly given by s_init_temp
%To get the distributions for e_init and i_init we run the CreateInitialDistribution again
[x1,alpha1,a1,b1]=CreateInitialDistribution(A,s_init_temp,sigma,gamma,beta);
%On the same day, we have 83.65 new cases. The formula for new cases is 
%diag(s_init)*beta*A*i_init*N. We know that i_init is a multiple of x1. Thus 
I_init=cases_total(1)/sum(diag(s_init_temp)*beta*A*x1)*x1';
%now the fraction b1/a1 tells how many more are in E_init
E_init=a1/b1*I_init;
%we finally pick S_init so that the total amount equals N
S_init=N*w-E_init-I_init-R_init;


%we now create the variales S,E,I,R and NU, which collects new cases
R=zeros(N_G,number_of_days);R(:,1) = R_init;
E=zeros(N_G,number_of_days);E(:,1) = E_init;
I=zeros(N_G,number_of_days);I(:,1) = I_init;
S=zeros(N_G,number_of_days);S(:,1) = S_init;
NU=zeros(N_G,number_of_days);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%The following line is just to ensure that the code looks similar for the
%various runs. Later we will include the fact that alpha was more
%infectious

beta_vec=beta*ones(1,number_of_days);





%below follows an implementation of the most basic code as described in
%Sections A1-A5

for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

%for plotting in fig 1 later 
new_cases1=sum(NU,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%in this run, we estimate that the alpha strain is 50% more infectious
%than the original strain, as estimated in reference [11]. This means that
%the beta value for alpha should gradually go up by factor 1.5, in proportion to the
%fraction of cases caused by the alpha-strain. The following lines creates
%such a timeseries.

frac_wuhan=cases_wuhan./cases_total;
frac_alpha=ones(1,number_of_days);
frac_alpha=frac_alpha-frac_wuhan;
alpha_increased_infectivity=1.5;
beta_vec=beta*(frac_wuhan+alpha_increased_infectivity*frac_alpha);

%we now compute what factor F we would need to get an exact fit with actual
%data, by a small update to the main code on lines 76-83. The update is
%found on lines 111-112. 
% Capital F is related to f in the paper by F=(1-f/100)

F=ones(1,number_of_days-1);

for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
F(t)=cases_total(t)/sum(NU(:,t),1);
NU(:,t)=F(t)*NU(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

%the F produced by the above code becomes too oscillatory, so we smoothen
%it by averaging over a month

F=[ones(1,12) F ones(1,17)*F(end)];
Fsmooth=conv(F,1/30*ones(1,30),'valid');
average_F_september=sum(Fsmooth(1:30))/30

%with this at hand, we now run the code 76-83 again, with the update that
%we multiply with Fsmooth on line 131

for t=1:number_of_days-1,
NU(:,t)=Fsmooth(t)*diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

new_cases2=sum(NU,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%we now repeat the code between 109 and 139 twice with different estimates
%of how much more infective alpha was, in order to produce the green zone
%displayed in Fig 4a

alpha_increased_infectivity=2.3;
beta_vec=beta*(frac_wuhan+alpha_increased_infectivity*frac_alpha);
F=ones(1,number_of_days-1);

for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
F(t)=cases_total(t)/sum(NU(:,t),1);
NU(:,t)=F(t)*NU(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

F=[ones(1,12) F ones(1,17)*F(end)];
Fsmoothup=conv(F,1/30*ones(1,30),'valid');

for t=1:number_of_days-1,
NU(:,t)=Fsmoothup(t)*diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


alpha_increased_infectivity=1.38;
beta_vec=beta*(frac_wuhan+alpha_increased_infectivity*frac_alpha);
F=ones(1,number_of_days-1);

for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
F(t)=cases_total(t)/sum(NU(:,t),1);
NU(:,t)=F(t)*NU(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

F=[ones(1,12) F ones(1,17)*F(end)];
Fsmoothdown=conv(F,1/30*ones(1,30),'valid');

for t=1:number_of_days-1,
NU(:,t)=Fsmoothdown(t)*diag(S(:,t)/N)*beta_vec(t)*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*[0 0 0 0 0 1]';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*[0 0 0 0 0 1]';
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)
plot(Fsmooth,'r','LineWidth',2);hold on;
plot(Fsmoothup,'k','LineWidth',2);
plot(Fsmoothdown,'k','LineWidth',2);
axis([1 number_of_days-1 0.5 1.15]);
title('Contacts reduction factor, "f"','FontSize',14);
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sep. 2020','Oct.','Nov.','Dec.','Jan. 2021','Feb.','Mar.','Apr.','May','Jun.', 'July'})
yticks([0.5 0.6 0.7 0.8 0.9 1 1.1])
yticklabels({'-50','-40','-30','-20','-10','0','10'})
x = [[1:number_of_days-1] [number_of_days-1:-1:1]];
inBetween = [Fsmoothup, fliplr(Fsmoothdown)];
fill(x, inBetween, 'g');
plot(Fsmooth,'r','LineWidth',2);
lgd=legend({'Assuming alpha is 50% more infectious','(upper) alpha is 38% more infectious','(lower) alpha is 130% more infectious'});
lgd.FontSize=11;
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Finally we make one run which includes also the activity stratification as
%introduced in Britton et al. [4]

w_act=[0.25 0.5 0.25];
f_act=[1/2 1 2];
f_act=f_act/sum(w_act.*f_act);
F_act=f_act'*f_act;
A=kron(A,F_act);
w=kron(w,w_act);
N_G=length(w);
beta=0.098;

R=zeros(N_G,number_of_days);R(:,1) = kron(R_init,w_act);
E=zeros(N_G,number_of_days);E(:,1) = kron(E_init,w_act);
I=zeros(N_G,number_of_days);I(:,1) = kron(I_init,w_act);
S=zeros(N_G,number_of_days);S(:,1) = kron(S_init,w_act);
NU=zeros(N_G,number_of_days);


for t=1:number_of_days-1,
NU(:,t)=diag(S(:,t)/N)*beta*A*I(:,t);
E(:,t+1)=E(:,t)+(NU(:,t)-sigma*E(:,t));
I(:,t+1)=I(:,t)+(sigma*E(:,t)-gamma*I(:,t));
Removed_by_vaccination=(v(t+1)-v(t))*0.7*S(6,t)/w(6);
S(:,t+1)=S(:,t)-NU(:,t)+(log(2)/half_life)*R(:,t)-Removed_by_vaccination*kron([0 0 0 0 0 1],w_act)';
R(:,t+1)=R(:,t)*1-(log(2)/half_life)*R(:,t)+gamma*I(:,t)+Removed_by_vaccination*kron([0 0 0 0 0 1],w_act)';
end

new_cases3=sum(NU,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
plot(cases_total,'b','LineWidth',2);hold on;
plot(new_cases1,'r','LineWidth',2);
plot(new_cases3,'k','LineWidth',2);
plot(new_cases2,'m','LineWidth',2);
plot(new_cases1,'r','LineWidth',2);

axis([1 number_of_days-1 0 14500]);
title('New infections, Stockholm county','FontSize',14);
xticks([1 31 62 92 123 154 182 213 243 274 304])
xticklabels({'Sep. 2020','Oct.','Nov.','Dec.','Jan. 2021','Feb.','Mar.','Apr.','May','Jun.', 'July'})
lgd=legend({'Measured data (rescaled)','Age-stratified SEIR','Age-act-stratified SEIR','Age-stratified SEIR with \newline variable contact pattern'});
lgd.FontSize = 11;


hold off