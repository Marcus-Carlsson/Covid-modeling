%clear all;
load('stockholm_data_weekly_average_200204_to_220727');
cases=stockholm_data_weekly_average;

%see Fig1a for explanation of the underreportingfactor 2.4, 24000000 is the amount of
%people in Stockholm County
immunity_increase_omicron=2.4*sum(cases(630:800))/24000000


%the coming lines are for displaying the time-frame of interest, which is
%between day 211 and 486
x=cases;
x(1:210)=-1000;
x(487:899)=-1000;

plot(cases,'LineWidth',2);hold on;
plot(x,'LineWidth',2);
title('New infections, Stockholm county','FontSize',16);
axis([1 length(cases) 0 9500]);
xticks([1 211 363 514 698 879])
xticklabels({'Feb.-20','Sep.-20','Feb.-21','June-21','Jan.-22','July-22'})
text(83,563,'\downarrow');
text(83-40,900,'First wave','FontSize',12);

text(283,2063,'\downarrow');
text(283-50,2450,'Second wave','FontSize',12);

text(413,1713,'\downarrow');
text(413-50,2000,'Third wave (alpha)','FontSize',12);

text(563,593,'\downarrow');
text(563-70,1200,'Fourth wave \newline (delta)','FontSize',12);

text(663,7000,'\rightarrow');
text(360,7000,'Fifth wave (omicron)','FontSize',12);


hold off;
 