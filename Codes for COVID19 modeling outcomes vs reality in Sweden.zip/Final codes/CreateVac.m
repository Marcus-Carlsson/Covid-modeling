%This script interpolates vaccinated by week to make it vaccinated by day.
%The first entry in vaccinated_2021_byweek is 1st week of 2021. The sunday
%of that week was the 10th of January, which is day 132 starting counting
%on the 1st of september 2020. We thus want the first value in vaccinated_2021_byweek
%to be achieved on day 132. Note that the full length of the time series we
%work with, i.e. stockholm_data_weekly_average_sept2020_to_may_2021 is 276,
%so we make the vector of vaccinated equally long, filling up the first 132
%days with 0s
load('vaccinated_2021_byweek.mat');
interpolating_dates=[1:7:22*7];
x=[1 (131+interpolating_dates)];
y=[0 vaccinated_2021_byweek];
vaccinated_by_day=interp1(x,y',[1:276]);

plot(vaccinated_by_day);

save('vaccinated_by_day.mat','vaccinated_by_day');