clear all;
% parameter values

psi=0;


% parameter values

 theta=0.3;
 thetaVoC=0.15;
%original pre-immunity 
 beta=0.123;
 betaVoC=0.179;
 T_VoC=330;
init_inf=40;
 T_window=581+55%there are 581 days on the figure axis, the rest is added since the figure axis stops,
 %using a ruler I estimated it to 55 extra days outside


t_infective = 2.1;gamma = 1/t_infective;
t_incubation = 4.6;sigma = 1/t_incubation;
delta=1;%factor for group isolation
xi=1;%factor for isolation of elderly
number_of_days = 1500;
N=2020000;%population_size
half_life=1.5*365;

%brasil population (using https://population.un.org/)
w=[0.085 0.096 0.105 0.362 0.291 0.061];%'0-5','6-12','13-19','17-39','40-69','>70'
%contact matrix
Abold=CreateA(w,delta,xi);

%number of subgroups
N_G=length(w);
%now comes formula (12) relating R0 and beta



%initial values


r=zeros(N_G,number_of_days);
e=zeros(N_G,number_of_days);e(:,1) = init_inf*w';
i=zeros(N_G,number_of_days);
s=N*diag(w)*ones(N_G,number_of_days);
s=s-e-i-r;
nu=zeros(N_G,number_of_days);

eVoC=zeros(N_G,number_of_days);
iVoC=zeros(N_G,number_of_days);
iVoC(:,T_VoC) = 10*w';
nuVoC=zeros(N_G,number_of_days);


for t=1:number_of_days-1,
nu(:,t)=diag(s(:,t)/N-theta*w')*beta*Abold*i(:,t);
e(:,t+1)=e(:,t)+(nu(:,t)-sigma*e(:,t));
i(:,t+1)=i(:,t)+(sigma*e(:,t)-gamma*i(:,t));
if t>=T_VoC,
    nuVoC(:,t)=diag(s(:,t)/N-thetaVoC*w')*betaVoC*Abold*iVoC(:,t);
    eVoC(:,t+1)=eVoC(:,t)+(nuVoC(:,t)-sigma*eVoC(:,t));
    iVoC(:,t+1)=iVoC(:,t)+(sigma*eVoC(:,t)-gamma*iVoC(:,t));
end
s(:,t+1)=s(:,t)-nu(:,t)-nuVoC(:,t)+(log(2)/half_life)*r(:,t);
r(:,t+1)=r(:,t)*1-(log(2)/half_life)*r(:,t)+gamma*iVoC(:,t)+gamma*i(:,t);
end

%we now collect the piece of the vector where something interesting happens
C19aug30=sum(r(:,184+17))/N%there are 184 days between march1 and sept 1, add 17 due to reason below
C19newyear=sum(r(:,366-60+17))/N%roughly the first 17 days are before march 1,so 366-60 is around new year
C19june30=sum(r(:,487+17))/N

%R0_true_march=beta*max(eig(diag(w)*Abold))/gamma
%R0_march=beta*max(eig(diag(w)*Abold))/gamma*(1-theta-psi)
%R0VoC_true_feb=betaVoC*max(eig(diag(w)*Abold))/gamma
%R0VoC_feb=betaVoC*max(eig(diag(w)*Abold))/gamma*(1-theta-C19midfeb)


%plotting

load('india_reweighted.mat')
figure(1)
g=sum(nu,1)/N+sum(nuVoC,1)/N;
plot(100*(g(1:690)),'k','LineWidth',2);hold on;
plot(india_reweighted(1:690),'LineWidth',2);
% plot(sum(nu2,1),'k','LineWidth',2);
% plot(sum(nu2B,1),'k','LineWidth',2);

axis([1 680 0 0.9]);
text(190,0.1,'Wuhan strain','FontSize',12);
text(430,0.1,'Delta strain','FontSize',12);
title('Incidence India (by John Hopkins University)')
legend({'Model with 30% preimmunity against the Wuhan strain\newline and 15% against the Delta strain','Measured cases reweighted to fit seroprevalence estimates by ICMR'},'Location','Northwest','FontSize',12)
xticks([1+24 32+24 62+24 93+24 123+24 154+24 185+24 215+24 246+24 276+24 307+24 337+24 1+389 32+389 62+389 93+389 123+389 154+389 185+389 215+389 246+389 276+389 307+389 337+389])
xticklabels({'Mar.-20','Apr.-20','May-20','Jun.-20','Jul.-20','Aug.-20','Sept.-20','Okt.-20','Nov-20','Dec-20', 'Jan-21','Feb.-21','Mar.-21','Apr.-21','May-21','Jun.-21','Jul.-21','Aug.-21','Sept.-21','Okt.-21','Nov-21','Dec-21', 'Jan','Feb'})
ylabel('Incidence in percent')
hold off;
