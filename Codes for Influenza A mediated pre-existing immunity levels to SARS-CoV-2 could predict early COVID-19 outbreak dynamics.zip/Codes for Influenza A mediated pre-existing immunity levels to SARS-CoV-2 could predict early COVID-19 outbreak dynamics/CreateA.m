function A=CreateA(w_age,delta,xi)
%This function creates the A matrix based on the M matrix found in Wallinga
%et al's paper, according to the adjustments described in our paper.
%delta: reduction for reduced contacts between age-groups
%xi: reduction for isolation of elderly
%Original dutch data 2006: w_age=[0.0725 0.0866 0.1124 0.3323 0.2267 0.1695];

M=[12.26    2.28    1.29    2.50    1.15    0.83;
   2.72    23.77    2.80    3.02    1.78    1.00;
   2.00     3.63   25.20    5.70    4.22    1.68;
  11.46    11.58   16.87   25.14   16.43    8.34;
   3.59     4.67    8.50   11.21   13.89    7.48;
   1.94     1.95    2.54    4.25    5.59    9.19];

Mnew=0.5*(M*diag(w_age)+(M*diag(w_age))')*diag(1./w_age);
A=diag(1./w_age)*Mnew/7;
A=delta*A+(1-delta)*A.*eye(6);
A(6,:)=xi*A(6,:);A(1:5,6)=xi*A(1:5,6);
end