clear all;
% parameter values
load('sthlm0610.mat');
st=2.4*sthlm3wave;%2.4 is the underreportingfactor, see Fig 1
sto=2.4*storig(end)*ones(length(st),1);%since value of storig is unclear 
%beyond week 14, we leave it fixed at the last value
sto(1:length(storig))=2.4*storig;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%1


k=0.00001;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2


% parameter values
R0=5.36;
t_infective = 2.1;gamma = 1/t_infective;
t_incubation = 4.6;sigma = 1/t_incubation;
Theta0=72;theta=Theta0/100;%preimmunity fraction

R0*(1-theta)

delta=1;%factor for group isolation
xi=1;%factor for isolation of elderly
eta=2;%factor for activitylevels
number_of_days = 500;
population_size=10000;


%swedish population 2020
w_age=[0.058 0.084 0.060 0.259 0.390 0.149];%'0-5','6-12','13-19','20-39','40-69','>70'
%original used by wallinga w_age=[0.0725 0.0866 0.1124 0.3323 0.2267 0.1695];
%we have updated the quota (using https://population.un.org/) and made the last group 70+ instead of 60+

%contact matrix
A=CreateA(w_age,delta,xi);
%adding activity levels
w_act=[0.25 0.5 0.25];
f_act=[1/eta 1 eta];
f_act=f_act/sum(w_act.*f_act);
F_act=f_act'*f_act;
Abold=kron(A,F_act);
w=kron(w_age,w_act);
%number of subgroups
N_G=length(w);
%now comes formula (12) relating R0 and beta
betamu=R0*gamma/max(eig(diag(w)*Abold));


%initial values
r_initial = 0.00*w;
e_initial = 1/population_size*w;
i_initial = 0.00*w;
s_initial = (1-theta)*w - i_initial - r_initial-e_initial;
y0=[s_initial, e_initial, i_initial, r_initial];

%we now solve the ODE, SEIR-function used is found in the end of this
%script

[t,y] = ode45(@(t,y) SEIRhetro(t,y,betamu,sigma,gamma,Abold,N_G),[0 number_of_days],y0);

%for convenience we reintroduce the proper names
s=y(:,1:N_G);
e=y(:,N_G+1:2*N_G);
i=y(:,2*N_G+1:3*N_G);
r=y(:,3*N_G+1:4*N_G);
nu=(s(1:end-1,:)-s(2:end,:))./(t(2:end)-t(1:end-1));
t=t(2:end);%nu is one element shorter than the rest, we need to drop the first value of each of the others to get it right
s=s(2:end,:);
e=e(2:end,:);
i=i(2:end,:);
r=r(2:end,:);
y=y(2:end,:);

%we now collect the piece of the vector where something interesting happens

id=sum(nu,2)>k;%when the new infections curve is above 5% of imax we also display
startpt=find(id,1,'first');
id=logical([zeros(1,startpt-1) ones(1,length(t)-startpt+1)]);


t=t(id);t=t-t(1);
y=y(id,:);
nu=nu(id,:);
s=s(id,:);
e=e(id,:);
i=i(id,:);
r=r(id,:);


endpt=find(t>350,1);
id=[1:endpt];
t=t(id);t=t;
y=y(id,:);
nu=nu(id,:);
s=s(id,:);
e=e(id,:);
i=i(id,:);
r=r(id,:);

nu=sum(nu,2);

disp('Final size of the epidemic:')
sum(r(end,:))
figure(1)

plot(sto*100/2400000,'LineWidth',2);hold on;
plot(t,nu*100,'LineWidth',2);








legend({'Actual cases','Age-Act SEIR \newline  R_0=1.5; Pre-immunity 62%'},'Location','northwest','FontSize',11)
axis([0,215,0,0.3]);
%xlabel('Time in days');
title('Incidence, Stockholm 2nd wave');
ylabel('Incidence in percent')

xticks([1 31 62 92 123 154 182 213])
xticklabels({'Sept.-20','Oct.-20','Nov.-20','Dec.-20','Jan.-20','Feb.-20','Mar.-20','Apr.-20'})
hold off;





%now comes the ODE, where y=[s;e;i;r]
function dydt=SEIRhetro(t,y,beta,sigma,gamma,A,N_G)
s=y(1:N_G);e=y(N_G+1:2*N_G);i=y(2*N_G+1:3*N_G);r=y(3*N_G+1:4*N_G);
dydt=[-diag(s)*beta*A*i;diag(s)*beta*A*i-sigma*e;sigma*e-gamma*i;gamma*i];
end
